import React, {Component} from 'react';
import {Platform,
    StyleSheet,
    Image,
    Text,
    View,
    ScrollView
} from 'react-native';
import Tts from 'react-native-tts';

let text = "ABCD EFG React Native is a JavaScript framework for writing real, natively rendering mobile applications for iOS and Android." +
    " It’s based on React, Facebook’s JavaScript library for building user interfaces, but instead of targeting" +
    " the browser, it targets mobile platforms. In other words: web developers can now write mobile applications" +
    " that look and feel truly “native,” all from the comfort of a JavaScript library that we already know and love." +
    " Plus, because most of the code you write can be shared between platforms, React Native makes it " +
    "easy to simultaneously develop for both Android and iOS.";

export default class Home extends Component {

    constructor(props) {
        super(props);
        this.state = {
            textDetail: text,
            read: '',
            unread: text
        }
    }

    componentDidMount() {
        Tts.speak(text, { iosVoiceId: 'com.apple.ttsbundle.Samantha-compact' });
        Tts.voices().then(voices => console.log(voices));
        Tts.addEventListener('tts-start', (event) => {console.log("start", event); this.manageText();});
        Tts.addEventListener('tts-finish', (event) => console.log("finish", event));
        Tts.addEventListener('tts-cancel', (event) => console.log("cancel", event));
        Tts.addEventListener('tts-progress', (event) => {
            const { textDetail } = this.state;
            const txtRead = textDetail.substr(0, event.location);
            const txtUnread = textDetail.replace(txtRead, '');
            this.setState({
                read: txtRead,
                unread: txtUnread
            });
            console.log("tts-progress", JSON.stringify(event));
        });
    }

    manageText = () => {
        setTimeout(()=>{
            this.manageText();
        },45);
    };

    render() {
        const { container, txtRead, txtUnread } = styles;
        const { read, unread } = this.state;
        return (
            <View style={container}>
                <Text style={txtRead}>
                    {read}
                    <Text style={txtUnread}>
                        {unread}
                    </Text>
                </Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent:'center',
        padding: 20
    },
    txtRead: {
        fontSize: 20,
        color: '#000',
        fontWeight: '600'
    },
    txtUnread: {
        color: '#bfbfbf',
        fontWeight: '400'
    }
});
