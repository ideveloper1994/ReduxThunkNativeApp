import React,{ Component } from 'react';
import {
    StyleSheet,
    SafeAreaView,
    View,
    FlatList,
    Text,
    Button
} from 'react-native';

export default class AddNote extends Component{

    static navigationOptions = ({ navigation }) => {
        return {
            title: 'Create Notes',

        };
    };

    constructor(props) {
        super(props);
        this.state = {
            noteDetail: ""
        };
    }

    render() {
        const { notes } = this.state;
        const { container } = styles;
        return(
            <SafeAreaView style={container}>

            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
});