import React,{ Component } from 'react';
import {
    StyleSheet,
    SafeAreaView,
    View,
    FlatList,
    Text,
    Button,
    TouchableOpacity
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import AddNote from "./addNote";
import NoteDetail from "./noteDetail";
import moment from 'moment';

export default class Notes extends Component{

    static navigationOptions = ({ navigation }) => {
        return {
            title: 'Notes',
            headerRight: (
                <Button
                    onPress={navigation.getParam('onAddNewNote')}
                    title='Add note'
                    color='rgb(13,99,255)'
                />
            ),
        };
    };

    constructor(props) {
        super(props);
        this.state = {
            notes:[
                {id: 1,title: 'Note 1',description: "React Native is a JavaScript framework for writing real."},
                {id: 2,title: 'Note 1',description: 'Test ....'},
                {id: 3,title: 'Note 1',description: 'Test ....'},
                {id: 4,title: 'Note 1',description: 'Test ....'},
                {id: 5,title: 'Note 1',description: 'Test ....'},
                {id: 6,title: 'Note 1',description: 'Test ....'},
                {id: 7,title: 'Note 1',description: 'Test ....'},
                {id: 8,title: 'Note 1',description: 'Test ....'},
                {id: 9,title: 'Note 1',description: 'Test ....'},
                {id: 10,title: 'Note 1',description: 'Test ....'},
                {id: 11,title: 'Note 1',description: 'Test ....'},
                {id: 12,title: 'Note 1',description: 'Test ....'},
                {id: 13,title: 'Note 1',description: 'Test ....'},
                {id: 14,title: 'Note 1',description: 'Test ....'},
            ]
        };
    }

    componentDidMount() {
        // let dateString = "2016-10-19 05:05:12";
        // let myDate = moment(dateString,"YYYY-MM-DD HH:mm:ss");
        // myDate.add(moment.duration(12,"seconds"));
        // alert(myDate.format("YYYY-MM-DD HH:mm:ss"));
        const { navigation } = this.props;
        navigation.setParams({ onAddNewNote: this.onAddNewNote });
    }

    onRowPress = (item) => {
        const { navigation } = this.props;
        navigation.navigate('NoteDetail', { noteData: item});
    };

    onAddNewNote = () => {
        const { navigation } = this.props;
        navigation.navigate('AddNote');
    };

    getColor = (index) => {
        //let index =  Math.floor(Math.random() * Math.floor(5));
        let colorIndex = index;
        if(colorIndex >= 7){
            colorIndex = colorIndex%7;
            colorIndex = Math.ceil(colorIndex);
        }
        const left = ['#fffda4','#ffb7be','#69a0e5','#35ebe9','#ff8a93','#685be9','#a256f1'];
        const right = ['#fdf4cc','#ffe5d6','#f0dbfb','#ceffaf','#fec180','#6acae1','#eeb9d4'];
        return {
            left: left[colorIndex],
            right: right[colorIndex]
        }
    };

    renderItem = ({ item, index }) => {
        const color = this.getColor(index);
        const { rowView, txtTitle, txtDetail } = styles;
        return(
            <TouchableOpacity onPress={()=>this.onRowPress(item)}>
                <LinearGradient colors={[color.left, color.right]}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 0 }}
                                style={ rowView }>
                    <Text style={ txtTitle }>
                        { item.title }
                    </Text>
                    <Text style={ txtDetail } numberOfLines={1}>
                        { item.description }
                    </Text>
                </LinearGradient>
            </TouchableOpacity>
        )
    };

    keyExtractor = (item) => {
        return item.id + '';
    };

    renderSeparator = () => {
        return (
            <View style={{height:10}}/>
        )
    };

    renderEmpty = () => {
        return(
            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                <Text>
                    {'No Data found'}
                </Text>
            </View>
        )
    };

    render() {
        const { notes } = this.state;
        const { container } = styles;
        return(
            <SafeAreaView style={container}>
                <FlatList data={notes}
                          contentContainerStyle={{paddingVertical:20}}
                          automaticallyAdjustContentInsets={false}
                          renderItem={this.renderItem}
                          keyExtractor={this.keyExtractor}
                          ItemSeparatorComponent={this.renderSeparator}
                          ListEmptyComponent={this.renderEmpty}
                />
            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    rowView: {
        paddingVertical:10,
        paddingStart:5,
        paddingEnd:15,
        marginHorizontal:10
    },
    txtTitle: {
        fontSize: 16,
        fontWeight: '700'
    },
    txtDetail: {
        fontSize: 15,
        fontWeight: '500'
    }
});