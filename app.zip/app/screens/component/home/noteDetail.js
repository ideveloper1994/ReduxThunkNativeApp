import React,{ Component } from 'react';
import {
    StyleSheet,
    SafeAreaView,
    View,
    Text,
    Button,
    ScrollView,
    PanResponder,
    Animated,
    Easing
} from 'react-native';
import Tts from 'react-native-tts';
import Constant from '../../../helper/themeHelper';

export default class NoteDetail extends Component{

    static navigationOptions = ({ navigation }) => {
        return {
            title: 'Note Detail',
        };
    };

    constructor(props) {
        super(props);
        this.state = {
            noteDetail: (props.navigation.state.params && props.navigation.state.params.noteData)
            && props.navigation.state.params.noteData || null,
            read: '',
            unread: (props.navigation.state.params && props.navigation.state.params.noteData)
            && props.navigation.state.params.noteData.description || '',
            sliderHeight: new Animated.Value(0),
        };
        this._panResponder = PanResponder.create({
            // Ask to be the responder:
            onStartShouldSetPanResponder: (evt, gestureState) => true,
            onStartShouldSetPanResponderCapture: (evt, gestureState) => true,
            onMoveShouldSetPanResponder: (evt, gestureState) => true,
            onMoveShouldSetPanResponderCapture: (evt, gestureState) => true,

            onPanResponderGrant: (evt, gestureState) => {
                // The gesture has started. Show visual feedback so the user knows
                // what is happening!
                // gestureState.d{x,y} will be set to zero now

            },
            onPanResponderMove: (evt, gestureState) => {
                // console.log('gestureState.y0 - ',gestureState.y0)
                // console.log('gestureState.moveY - ',gestureState.moveY)

                // const value = gestureState.y0-gestureState.moveY;
                // if(value > 0){

                    let value = (((Constant.screenHeight-400+200)-gestureState.moveY) > 400) || 400;

                console.log(value)

                    if(value <= 400 && value > 50){
                        this.state.sliderHeight.setValue((Constant.screenHeight-400+200)-gestureState.moveY)
                    }
                // }

                // The most recent move distance is gestureState.move{X,Y}
                // The accumulated gesture distance since becoming responder is
                // gestureState.d{x,y}
            },
            onPanResponderTerminationRequest: (evt, gestureState) => true,
            onPanResponderRelease: (evt, gestureState) => {


                // console.log(this.state.sliderHeight._value)

                // The user has released all touches while this view is the
                // responder. This typically means a gesture has succeeded
            },
            onPanResponderTerminate: (evt, gestureState) => {
                // Another component has become the responder, so this gesture
                // should be cancelled
            },
            onShouldBlockNativeResponder: (evt, gestureState) => {
                // Returns whether this component should block native components from becoming the JS
                // responder. Returns true by default. Is currently only supported on android.
                return true;
            },
        });
    }

    componentDidMount() {
        setTimeout(()=>{
            // this.onPlayNotes();
        },1000);
    }

    componentWillUnmount() {
        Tts.stop();
        Tts.removeEventListener('tts-start');
        Tts.removeEventListener('tts-finish');
        Tts.removeEventListener('tts-cancel');
        Tts.removeEventListener('tts-progress');
    }

    onPlayNotes = () => {
        const { noteDetail } = this.state;
        const { title, description } = noteDetail;
        Tts.setDefaultRate(0.1);
        Tts.speak(description, { iosVoiceId: 'com.apple.ttsbundle.Samantha-compact' });
        Tts.voices().then(voices => console.log(voices));
        Tts.addEventListener('tts-start', this.manageText);
        Tts.addEventListener('tts-finish', this.manageText);
        Tts.addEventListener('tts-cancel', this.manageText);
        Tts.addEventListener('tts-progress', this.manageText);
    };

    manageText = (event) => {
        const { noteDetail } = this.state;
        const txtRead = noteDetail.description.substr(0, event.location);
        const txtUnread = noteDetail.description.replace(txtRead, '');
        this.setState({
            read: txtRead,
            unread: txtUnread
        });
    };

    render() {
        const { noteDetail, read, unread } = this.state;
        const { title } = noteDetail || { title: ""};
        const { container, txtTitle, txtUnread, txtRead } = styles;
        return(
            <SafeAreaView style={container}>
                <View style={{ flexDirection: 'row', flex: 1 }}>
                    <ScrollView contentContainerStyle={{padding:20}}>
                        <Text style={ txtTitle }>
                            { title }
                        </Text>
                        <Text style={txtUnread}>
                            {read}
                            <Text style={txtRead}>
                                {unread}
                            </Text>
                        </Text>
                    </ScrollView>
                    <View style={{paddingLeft:20,paddingRight:20, justifyContent:'center'}}>
                        <View style={{width: 25,height:400,justifyContent:'flex-end',backgroundColor:'red',overflow:'hidden',
                            borderRadius:10}}
                              {...this._panResponder.panHandlers}>
                            <Animated.View
                                style={[
                                    {
                                        borderRadius:10,
                                        height: this.state.sliderHeight,
                                        width: 25,
                                        backgroundColor: "#ff0",
                                        bottom:0
                                    }
                                ]}
                            />
                        </View>
                    </View>
                </View>
                <View style={{height:80}}>

                </View>

            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingVertical:20,
        paddingHorizontal:10
    },
    txtTitle: {
        fontSize: 16,
        fontWeight: '700',
        marginBottom: 10
    },
    txtUnread: {
        fontSize: 15,
        fontWeight: '500',
        lineHeight: 24,
        color: '#000'
    },
    txtRead:{
        color: '#b4b4b4'
    }
});