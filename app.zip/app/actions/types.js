export const USER_DETAILS = 'USER_DETAILS';
export const RESET_STORE = 'RESET_STORE';
