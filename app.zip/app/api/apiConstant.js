module.exports = {
    //API Constant
    BASE_URL: 'http://localhost/node_api/',
    USER_LOGIN: 'login'
};