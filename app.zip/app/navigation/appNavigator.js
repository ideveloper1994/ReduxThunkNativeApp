import { createStackNavigator, createAppContainer } from 'react-navigation';
import UserLogin from '../screens/containers/login/index';
import Home from '../screens/component/home/index';
import AdsDemo from '../screens/component/addDemo';
import Notes from '../screens/component/home/notesList';
import AddNote from '../screens/component/home/addNote';
import NoteDetail from '../screens/component/home/noteDetail';

const AppNavigator = createStackNavigator({
    Notes,
    AddNote,
    NoteDetail,
    AdsDemo,
    Home,
    UserLogin
},{
    //headerMode: 'none',
    initialRouteName: 'Notes'
});

const AppContainer = createAppContainer(AppNavigator);
export default AppContainer;
