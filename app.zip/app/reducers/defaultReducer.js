import { userDefault } from './default/user';

export const appDefaultReducer = {
    user: userDefault
};