export const userDefault = {
    userDetail: {},
};
